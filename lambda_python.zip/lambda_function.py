import json
import boto3

def lambda_handler(event, context):
    
    x =  '{ "num1":2, "num2":30}'
    
    x = json.loads(x)
    
    y = x["num1"]
    y2 = x["num2"]
    
    x = int(y) + int(y2)
    x = str(x)
    
    client = boto3.client('sns')
    snsArn = 'arn:aws:sns:us-east-1:264574450100:lambda-sns'
    message = x
    
    response = client.publish(
        TopicArn = snsArn,
        Message = message ,
        Subject='Hello'
    )